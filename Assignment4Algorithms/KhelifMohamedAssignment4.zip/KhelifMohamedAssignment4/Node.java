/**
 * Created by mohamed on 7/22/17.
 */

class Node {
    int key;
    int height;
    Node left;
    Node right;

    Node(int d) {
        key = d;
        height = 1;
    }
}
